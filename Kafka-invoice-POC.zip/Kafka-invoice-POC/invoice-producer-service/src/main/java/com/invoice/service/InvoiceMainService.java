package com.invoice.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InvoiceMainService {

	public static void main(String[] args) {
		SpringApplication.run(InvoiceMainService.class, args);
	}
}
