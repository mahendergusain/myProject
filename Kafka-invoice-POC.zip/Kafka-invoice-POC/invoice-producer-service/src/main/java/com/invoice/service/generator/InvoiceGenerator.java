package com.invoice.service.generator;

import com.invoice.service.model.InvoiceData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.ArrayList;

@RestController
public class InvoiceGenerator {

    @Autowired
    private KafkaTemplate<String, InvoiceData> kafkaTemplate;

    private static final String TOPIC = "invoice_topic";

    @GetMapping("/generateInvoice/{invoiceNumber}")
    public String generateInvoice(@PathVariable("invoiceNumber") final Integer invoiceNumber) {
        // Create an InvoiceData object with sample data
        InvoiceData invoiceData = new InvoiceData(invoiceNumber, "CustomerName", 12000.0, LocalDate.now(), new ArrayList<>());


        // Send the JSON data to Kafka
        kafkaTemplate.send(TOPIC, invoiceData);

        return "Invoice Data Published successfully";
    }


}
