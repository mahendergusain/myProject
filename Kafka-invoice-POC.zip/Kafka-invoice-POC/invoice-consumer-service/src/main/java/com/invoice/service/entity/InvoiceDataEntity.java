package com.invoice.service.entity;

import org.springframework.data.cassandra.mapping.PrimaryKey;
import org.springframework.data.cassandra.mapping.Table;

import java.time.LocalDate;
import java.util.List;

@Table("invoice_data")
public class InvoiceDataEntity {

    @PrimaryKey
    private Integer invoiceNumber;
    private String customerName;
    private Double totalAmount;
    private LocalDate invoiceDate;
    private List<InvoiceItemEntity> invoiceItems; // Assuming you have an InvoiceItemEntity class

    public Integer getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(Integer invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public LocalDate getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(LocalDate invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public List<InvoiceItemEntity> getInvoiceItems() {
        return invoiceItems;
    }

    public void setInvoiceItems(List<InvoiceItemEntity> invoiceItems) {
        this.invoiceItems = invoiceItems;
    }
}
