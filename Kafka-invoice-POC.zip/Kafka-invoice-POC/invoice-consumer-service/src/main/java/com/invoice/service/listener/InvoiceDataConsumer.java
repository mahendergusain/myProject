package com.invoice.service.listener;

import com.invoice.service.model.InvoiceData;
import com.invoice.service.repository.InvoiceDataRepository;
import com.invoice.service.entity.InvoiceDataEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class InvoiceDataConsumer {
    @Autowired
    private InvoiceDataRepository invoiceDataRepository;

    @KafkaListener(topics = "invoice-topic",groupId = "invoice_json", containerFactory = "invoiceKafkaListenerFactory")
    public void consumeInvoiceData(InvoiceData invoiceData) {

        InvoiceDataEntity invoiceDataEntity = mapInvoiceDataToEntity(invoiceData);

        // Save to Cassandra
        invoiceDataRepository.save(invoiceDataEntity);
    }

    private InvoiceDataEntity mapInvoiceDataToEntity(InvoiceData invoiceData) {
        // Implement JSON deserialization logic
        // Parse JSON and populate the InvoiceDataEntity
        // Replace this with your actual deserialization code
        return new InvoiceDataEntity();
    }
}
